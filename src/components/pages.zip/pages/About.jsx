// src/components/pages/About.jsx
"use client";

import React from "react";
import { Award, Users, MapPin } from "lucide-react";
import PageShell from "@/components/shared/PageShell";
import AnimatedSection from "@/components/shared/AnimatedSection";
import { Panel } from "@/components/ui/panel";
import BottomCTA from "@/components/shared/BottomCTA";

const MEDIA = {
  hero: "/images/about/hero.jpg",
  authority: "/images/about/authority.jpg",
  chris: "/images/about/chris.jpg",
  matt: "/images/about/matt.jpg",
};

const METRICS = [
  {
    icon: Award,
    value: "27+ Years",
    description:
      "Licensed landscape architecture practice serving Texas clients since 1997",
  },
  {
    icon: Users,
    value: "500+ Projects",
    description:
      "Residential estates, commercial developments, and community landscapes completed",
  },
  {
    icon: MapPin,
    value: "Regional Focus",
    description:
      "The Woodlands, Houston, and surrounding Montgomery and Harris county communities",
  },
];

const APPROACH = [
  {
    title: "Planning",
    description:
      "Site analysis, grading strategy, drainage design, and construction documentation that accounts for existing conditions, municipal requirements, and buildability constraints.",
  },
  {
    title: "Execution",
    description:
      "In-house construction crews managing hardscape installation, grading, irrigation, and planting—ensuring design intent translates to built reality without coordination gaps.",
  },
  {
    title: "Stewardship",
    description:
      "Long-term project support, warranty service, and consultation for landscape maintenance strategies that preserve design quality and system performance.",
  },
];

const HISTORY = [
  "ELI land design was founded in 1997 by Chris K. Eiseman with a strong work ethic and a commitment to quality.",
  "With expertise in both design and construction, the firm delivers full-scope landscape architecture from conceptual planning through installation.",
  "That founding mindset continues today—focused on craftsmanship, collaboration, and building spaces that perform in the real world.",
];

const TIMELINE = [
  { year: "1997", label: "Founded by Chris K. Eiseman" },
  { year: "2002", label: "Chris graduates Texas A&M" },
  { year: "2012", label: "Matt Louderback joins as RLA" },
  { year: "Today", label: "27+ years of excellence" },
];

const TEAM = [
  {
    label: "Founder & Lead Designer",
    name: "Chris K. Eiseman",
    suffix: "RLA",
    image: MEDIA.chris,
    bio:
      "With over 27 years of experience, Chris brings both design and construction expertise to every project.",
  },
  {
    label: "Landscape Architect",
    name: "Matt Louderback",
    suffix: "RLA",
    image: MEDIA.matt,
    bio:
      "Matt focuses on design development, construction documentation, and visualization.",
  },
];

function TeamCard({ person }) {
  return (
    <Panel className="overflow-hidden border border-[#1F2E23]/10 bg-white">
      <img
        src={person.image}
        alt={`${person.name}, ${person.suffix}`}
        className="w-full aspect-[4/3] object-cover"
      />
      <div className="p-5 md:p-6">
        <h3 className="type-h3 text-[#1F2E23]">
          {person.name}, {person.suffix}
        </h3>
        <div className="type-micro mt-2 text-[#D86F3D]">
          {person.label}
        </div>
        <p className="type-body mt-4 text-eli-muted">
          {person.bio}
        </p>
      </div>
    </Panel>
  );
}

export default function About() {
  return (
    <PageShell
      hero
      heroImage={MEDIA.hero}
      eyebrow="About ELI Land Design"
      title="Landscape Architecture & Construction Services in Texas"
      subtitle="27+ Years of experience delivering landscape architecture and construction services across Texas."
    >
      <section className="py-12 px-6 md:px-12 lg:px-20 max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
          <div className="space-y-8">
            <AnimatedSection>
              <h2 className="type-h2 text-[#1F2E23]">
                Technical site planning.
                <br />
                Quality construction.
              </h2>
            </AnimatedSection>

            <AnimatedSection delay={0.1}>
              <Panel>
                <img
                  src={MEDIA.authority}
                  alt="Landscape design planning"
                  className="w-full aspect-[4/3] object-cover"
                />
              </Panel>
            </AnimatedSection>
          </div>

          <div className="space-y-6">
            <AnimatedSection>
              <p className="type-body text-eli-muted">
                ELI Land Design provides landscape architecture and site planning
                built for real-world conditions—balancing aesthetics,
                constructability, and long-term performance.
              </p>
            </AnimatedSection>

            <AnimatedSection delay={0.1}>
              <p className="type-body text-eli-muted">
                Services include master planning, grading, drainage, irrigation,
                planting plans, and full design-build coordination.
              </p>
            </AnimatedSection>

            <AnimatedSection delay={0.2}>
              <p className="type-body text-eli-muted">
                The firm specializes in technically challenging sites and complex
                coordination environments.
              </p>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <section className="py-12 px-6 md:px-12 lg:px-20 border-t border-[#1F2E23]/10">
        <div className="grid md:grid-cols-3 gap-10">
          {METRICS.map((m, i) => {
            const Icon = m.icon;
            return (
              <AnimatedSection key={m.value} delay={i * 0.1}>
                <div className="flex gap-4">
                  <Icon className="w-5 h-5 text-[#6B7F5E]" />
                  <div>
                    <div className="type-h3 text-[#1F2E23]">{m.value}</div>
                    <p className="type-small text-eli-muted mt-1">
                      {m.description}
                    </p>
                  </div>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
      </section>

      <section className="bg-[#1F2E23] py-12 px-6 md:px-12 lg:px-20">
        <h2 className="type-h2 text-[#F5F0EA] mb-10">
          Professional Approach
        </h2>

        <div className="grid md:grid-cols-3 gap-10">
          {APPROACH.map((a) => (
            <div key={a.title}>
              <h3 className="type-h3 text-[#F5F0EA]">{a.title}</h3>
              <p className="type-body text-white/70 mt-3">
                {a.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 px-6 md:px-12 lg:px-20">
        <h2 className="type-h2 text-[#1F2E23] mb-6">Our Team</h2>

        <div className="grid md:grid-cols-2 gap-8">
          {TEAM.map((p) => (
            <TeamCard key={p.name} person={p} />
          ))}
        </div>
      </section>

      <BottomCTA />
    </PageShell>
  );
}