// src/Layout.jsx
"use client";

import React, { useEffect, useMemo, useState } from "react";
import { usePathname } from "next/navigation";
import SiteHeader from "./components/SiteHeader";
import SiteFooter from "./components/SiteFooter";
import {
  trackPageView,
  startEngagementTimer,
  createScrollDepthTracker,
} from "@/lib/intelligence";

export default function Layout({ children, currentPageName }) {
  const pathname = usePathname();
  const HEADER_OFFSET = "pt-20 md:pt-24";

  // Routes that should render "hero under header" (transparent header style)
  const HERO_ROUTE_MATCHERS = useMemo(
    () => [
      (p) => p === "/",
      (p) => p === "/about",
      (p) => p === "/contact",
      (p) => p === "/reviews",
      (p) => p === "/careers-at-eli",
      (p) => p.startsWith("/design"),
      (p) => p.startsWith("/construction"),
      (p) => p.startsWith("/projects"),
      (p) => p.startsWith("/portfolio"),
      (p) => p.startsWith("/gallery"),
    ],
    []
  );

  const [hasHeroClass, setHasHeroClass] = useState(false);

  // Read PageShell body class (eli-has-hero) if present
  useEffect(() => {
    if (typeof document === "undefined") return;

    const read = () => {
      setHasHeroClass(document.body.classList.contains("eli-has-hero"));
    };

    read();

    const Obs =
      typeof MutationObserver !== "undefined" ? MutationObserver : null;
    if (!Obs) return;

    const observer = new Obs(read);
    observer.observe(document.body, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => observer.disconnect();
  }, [pathname]);

  const heroUnderHeader =
    hasHeroClass || HERO_ROUTE_MATCHERS.some((fn) => fn(pathname));

  // ✅ Hook 1: Page view (once per route)
  useEffect(() => {
    trackPageView({ page: currentPageName || "unknown" });
  }, [pathname, currentPageName]);

  // ✅ Hook 2: Engagement timer (time on page)
  useEffect(() => {
    const stop = startEngagementTimer({ page: currentPageName || "unknown" });
    return stop;
  }, [pathname, currentPageName]);

  // ✅ Hook 3: Scroll depth (throttled + thresholds)
  useEffect(() => {
    if (typeof window === "undefined") return;

    const onScroll = createScrollDepthTracker({
      extras: { page: currentPageName || "unknown" },
    });

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll(); // initial ping

    return () => window.removeEventListener("scroll", onScroll);
  }, [pathname, currentPageName]);

  return (
    <div className="min-h-screen bg-[#F5F0EA]">
      <SiteHeader
        currentPageName={currentPageName}
        heroUnderHeader={heroUnderHeader}
      />

      <div className={heroUnderHeader ? "" : HEADER_OFFSET}>{children}</div>

      <SiteFooter />
    </div>
  );
}