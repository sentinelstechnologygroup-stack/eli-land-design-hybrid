// src/components/shared/PageHero.jsx
"use client";

import React from "react";

export default function PageHero({
  label,
  title,
  subtitle,
  image,
  heroExtras = null,
  heightClass = "h-[48vh] min-h-[340px] max-h-[560px]",
  contentMax = "max-w-[1440px]",
  titleClassName = "",
  subtitleClassName = "",
  contentAlign = "end",
}) {
  const verticalAlignClass =
    contentAlign === "center"
      ? "items-center pb-0"
      : "items-end pb-10 md:pb-12";

  return (
    <section className={`relative w-full overflow-hidden ${heightClass}`}>
      {image ? (
        <img
          src={image}
          alt=""
          className="absolute inset-0 h-full w-full object-cover object-center"
          loading="eager"
          decoding="async"
        />
      ) : (
        <div className="absolute inset-0 bg-[#1F2E23]" />
      )}

      <div className="absolute inset-0 bg-[#040907]/74" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#020403]/88 via-[#06100B]/68 to-[#08110C]/92" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#06100B]/58 via-[#06100B]/28 to-[#06100B]/42" />
      <div className="absolute inset-0 backdrop-[brightness(.46)]" />
      <div className="absolute inset-x-0 bottom-0 h-[46%] bg-gradient-to-t from-[#050906]/96 to-transparent" />

      <div className="absolute inset-0">
        <div className={`${contentMax} mx-auto h-full px-6 md:px-12 lg:px-20`}>
          <div className={`flex h-full ${verticalAlignClass}`}>
            <div className="w-full max-w-[1240px]">
              {label ? (
                <div className="mb-4 type-micro text-[#F5F0EA] [text-shadow:0_3px_18px_rgba(0,0,0,0.72)]">
                  {label}
                </div>
              ) : null}

              {title ? (
                <h1
                  className={[
                    "font-serif-display font-semibold text-[#F5F0EA]",
                    "text-[clamp(2.1rem,3.6vw,3.7rem)] leading-[0.96] tracking-[-0.03em]",
                    "[text-shadow:0_6px_28px_rgba(0,0,0,0.82)] [text-wrap:balance]",
                    "max-w-[18ch] sm:max-w-[19ch] md:max-w-[20ch] lg:max-w-[21ch] xl:max-w-[22ch]",
                    titleClassName,
                  ].join(" ").trim()}
                >
                  {title}
                </h1>
              ) : null}

              {subtitle ? (
                <p
                  className={[
                    "mt-5 max-w-[46rem] font-sans-clean text-[15px] leading-[1.72] text-[#F5F0EA] md:text-[17px]",
                    "[text-shadow:0_4px_18px_rgba(0,0,0,0.76)]",
                    subtitleClassName,
                  ].join(" ").trim()}
                >
                  {subtitle}
                </p>
              ) : null}

              {heroExtras ? <div className="mt-6">{heroExtras}</div> : null}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}