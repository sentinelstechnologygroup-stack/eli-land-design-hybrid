"use client";

import React from "react";
import Link from "next/link";
import PageShell from "@/components/shared/PageShell";

export default function Home() {
  return (
    <PageShell>

      {/* ================= HERO / MAIN BANNER ================= */}
      <section className="relative w-full h-[75vh] overflow-hidden">

        <div className="absolute inset-0 grid grid-cols-3">
          {/* LEFT IMAGE */}
          <img
            src="/images/banner/banner-1.jpg"
            alt=""
            className="w-full h-full object-cover"
          />

          {/* CENTER IMAGE */}
          <img
            src="/images/banner/banner-2.jpg"
            alt=""
            className="w-full h-full object-cover"
          />

          {/* RIGHT IMAGE */}
          <img
            src="/images/banner/banner-3.jpg"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>

        {/* Overlay */}
        <div className="absolute inset-0 bg-black/45" />

        {/* Text */}
        <div className="relative z-10 flex items-center justify-center h-full text-center text-white px-6">
          <div>
            <h1 className="text-4xl md:text-5xl font-semibold mb-4">
              Landscape Architecture,
              <br />
              Site Planning & Landscape Construction Service
            </h1>
          </div>
        </div>
      </section>

      {/* ================= MAIN GRID ================= */}
      <section className="max-w-[1440px] mx-auto px-6 py-16 grid md:grid-cols-2 gap-6">

        {/* COMMERCIAL */}
        <Link href="/gallery/commercial" className="group relative h-[340px] overflow-hidden">
          <img
            src="/images/renderings/commercial/commercial-1.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative z-10 p-6 text-white flex flex-col justify-end h-full">
            <h2 className="text-2xl font-semibold mb-2">
              Commercial Landscape Architecture
            </h2>
            <span className="text-sm tracking-wide">VIEW GALLERY</span>
          </div>
        </Link>

        {/* RESIDENTIAL */}
        <Link href="/gallery/residential" className="group relative h-[340px] overflow-hidden">
          <img
            src="/images/renderings/residential/residential-1.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative z-10 p-6 text-white flex flex-col justify-end h-full">
            <h2 className="text-2xl font-semibold mb-2">
              Residential Landscape Architecture
            </h2>
            <span className="text-sm tracking-wide">VIEW GALLERY</span>
          </div>
        </Link>

        {/* ABOUT */}
        <Link href="/about" className="group relative h-[340px] overflow-hidden">
          <img
            src="/images/home/about.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative z-10 p-6 text-white flex flex-col justify-end h-full">
            <h2 className="text-2xl font-semibold mb-2">
              About ELI Land Design
            </h2>
            <span className="text-sm tracking-wide">VIEW PAGE</span>
          </div>
        </Link>

        {/* GALLERY (RENDER FEATURE TILE) */}
        <Link href="/gallery" className="group relative h-[340px] overflow-hidden">
          <img
            src="/images/renderings/commercial/featured.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative z-10 p-6 text-white flex flex-col justify-end h-full">
            <h2 className="text-2xl font-semibold mb-2">
              Gallery
            </h2>
            <span className="text-sm tracking-wide">VIEW GALLERY</span>
          </div>
        </Link>

        {/* REVIEWS */}
        <Link href="/reviews" className="group relative h-[340px] overflow-hidden">
          <img
            src="/images/home/reviews.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative z-10 p-6 text-white flex flex-col justify-end h-full">
            <h2 className="text-2xl font-semibold mb-2">
              Client Reviews
            </h2>
            <span className="text-sm tracking-wide">VIEW REVIEWS</span>
          </div>
        </Link>

        {/* CAREERS */}
        <Link href="/careers" className="group relative h-[340px] overflow-hidden">
          <img
            src="/images/home/careers.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative z-10 p-6 text-white flex flex-col justify-end h-full">
            <h2 className="text-2xl font-semibold mb-2">
              Careers at ELI Land Design
            </h2>
            <span className="text-sm tracking-wide">VIEW CAREERS</span>
          </div>
        </Link>

      </section>
    </PageShell>
  );
}